# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[7.0].define(version: 2022_11_02_163916) do
  create_table "activities", id: { type: :binary, limit: 26 }, charset: "utf8mb4", collation: "utf8mb4_unicode_ci", force: :cascade do |t|
    t.string "name", null: false
    t.string "additional_text"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "admins", id: { type: :binary, limit: 26 }, charset: "utf8mb4", collation: "utf8mb4_unicode_ci", force: :cascade do |t|
    t.boolean "enabled", default: true, null: false
    t.text "first_name_ciphertext"
    t.text "last_name_ciphertext"
    t.string "time_zone"
    t.text "email_ciphertext", null: false
    t.string "email_bidx", null: false
    t.string "encrypted_password", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at", precision: nil
    t.datetime "remember_created_at", precision: nil
    t.string "confirmation_token"
    t.datetime "confirmed_at", precision: nil
    t.datetime "confirmation_sent_at", precision: nil
    t.text "unconfirmed_email_ciphertext"
    t.string "unconfirmed_email_bidx"
    t.integer "failed_attempts", default: 0, null: false
    t.string "unlock_token"
    t.datetime "locked_at", precision: nil
    t.string "invitation_token"
    t.datetime "invitation_created_at", precision: nil
    t.datetime "invitation_sent_at", precision: nil
    t.datetime "invitation_accepted_at", precision: nil
    t.integer "invitation_limit"
    t.string "invited_by_type"
    t.binary "invited_by_id", limit: 26
    t.integer "invitations_count", default: 0
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["confirmation_token"], name: "index_admins_on_confirmation_token", unique: true
    t.index ["email_bidx"], name: "index_admins_on_email_bidx", unique: true
    t.index ["invitation_token"], name: "index_admins_on_invitation_token", unique: true
    t.index ["invitations_count"], name: "index_admins_on_invitations_count"
    t.index ["invited_by_id"], name: "index_admins_on_invited_by_id"
    t.index ["invited_by_type", "invited_by_id"], name: "index_admins_on_invited_by_type_and_invited_by_id"
    t.index ["reset_password_token"], name: "index_admins_on_reset_password_token", unique: true
    t.index ["unconfirmed_email_bidx"], name: "index_admins_on_unconfirmed_email_bidx", unique: true
    t.index ["unlock_token"], name: "index_admins_on_unlock_token", unique: true
  end

  create_table "demographic_surveys", id: { type: :binary, limit: 26 }, charset: "utf8mb4", collation: "utf8mb4_unicode_ci", force: :cascade do |t|
    t.binary "user_id", limit: 26, null: false
    t.string "age", null: false
    t.string "gender", null: false
    t.string "living_situation", null: false
    t.string "annual_net_income", null: false
    t.json "money_sources", null: false
    t.string "highest_education", null: false
    t.string "duration_in_canada", null: false
    t.json "race", null: false
    t.string "current_gambling_treatment", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["user_id"], name: "index_demographic_surveys_on_user_id"
  end

  create_table "emotions", id: { type: :binary, limit: 26 }, charset: "utf8mb4", collation: "utf8mb4_unicode_ci", force: :cascade do |t|
    t.string "name", null: false
    t.string "color", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "games", id: { type: :binary, limit: 26 }, charset: "utf8mb4", collation: "utf8mb4_unicode_ci", force: :cascade do |t|
    t.string "title", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "journals", id: { type: :binary, limit: 26 }, charset: "utf8mb4", collation: "utf8mb4_unicode_ci", force: :cascade do |t|
    t.string "journal_type"
    t.binary "user_id", limit: 26, null: false
    t.datetime "gambling_start_at", precision: nil
    t.datetime "gambling_end_at", precision: nil
    t.boolean "won_money", default: false, null: false
    t.decimal "total_money", precision: 12, scale: 2
    t.integer "intensity"
    t.boolean "substances_used", default: false, null: false
    t.boolean "urge_outcome", default: false, null: false
    t.text "location"
    t.text "gambling_type"
    t.text "feelings_before"
    t.text "feelings_during"
    t.text "feelings_after"
    t.text "thoughts"
    t.text "people"
    t.text "activities"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["user_id"], name: "index_journals_on_user_id"
  end

  create_table "locations", id: { type: :binary, limit: 26 }, charset: "utf8mb4", collation: "utf8mb4_unicode_ci", force: :cascade do |t|
    t.string "title", null: false
    t.string "additional_text"
    t.string "urge_type", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "people", id: { type: :binary, limit: 26 }, charset: "utf8mb4", collation: "utf8mb4_unicode_ci", force: :cascade do |t|
    t.string "title", null: false
    t.string "urge_type", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "screeners", id: { type: :binary, limit: 26 }, charset: "utf8mb4", collation: "utf8mb4_unicode_ci", force: :cascade do |t|
    t.binary "user_id", limit: 26, null: false
    t.string "screener_type", null: false
    t.integer "score"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["user_id"], name: "index_screeners_on_user_id"
  end

  create_table "thoughts", id: { type: :binary, limit: 26 }, charset: "utf8mb4", collation: "utf8mb4_unicode_ci", force: :cascade do |t|
    t.string "title", null: false
    t.string "urge_type", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "users", id: { type: :binary, limit: 26 }, charset: "utf8mb4", collation: "utf8mb4_unicode_ci", force: :cascade do |t|
    t.boolean "active", default: true, null: false
    t.string "time_zone"
    t.string "provider", default: "email", null: false
    t.string "uid_ciphertext", null: false
    t.string "uid_bidx", null: false
    t.json "tokens"
    t.text "email_ciphertext"
    t.string "email_bidx"
    t.string "encrypted_password", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at", precision: nil
    t.boolean "allow_password_change", default: true, null: false
    t.datetime "remember_created_at", precision: nil
    t.string "confirmation_token"
    t.datetime "confirmed_at", precision: nil
    t.datetime "confirmation_sent_at", precision: nil
    t.text "unconfirmed_email_ciphertext"
    t.string "unconfirmed_email_bidx"
    t.integer "failed_attempts", default: 0, null: false
    t.string "unlock_token"
    t.datetime "locked_at", precision: nil
    t.datetime "privacy_accept_date"
    t.datetime "deactivation_date"
    t.datetime "enrollment_date"
    t.datetime "first_visit_date"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["confirmation_token"], name: "index_users_on_confirmation_token", unique: true
    t.index ["email_bidx"], name: "index_users_on_email_bidx", unique: true
    t.index ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true
    t.index ["uid_bidx"], name: "index_users_on_uid_bidx", unique: true
    t.index ["unconfirmed_email_bidx"], name: "index_users_on_unconfirmed_email_bidx"
    t.index ["unlock_token"], name: "index_users_on_unlock_token", unique: true
  end

  add_foreign_key "demographic_surveys", "users"
  add_foreign_key "journals", "users"
  add_foreign_key "screeners", "users"
end
