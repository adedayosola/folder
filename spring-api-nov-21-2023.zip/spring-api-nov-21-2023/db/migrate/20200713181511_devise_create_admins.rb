class DeviseCreateAdmins < ActiveRecord::Migration[6.0]
  def change
    create_table :admins, id: false do |t|
      t.binary :id, limit: 26, primary_key: true

      ## Custom Attributes
      t.boolean :enabled, null: false, default: true
      t.text :first_name_ciphertext
      t.text :last_name_ciphertext
      t.string :time_zone

      ## Database authenticatable
      t.text :email_ciphertext, null: false
      t.string :email_bidx, null: false
      t.string :encrypted_password, null: false

      ## Recoverable
      t.string   :reset_password_token
      t.datetime :reset_password_sent_at

      ## Rememberable
      t.datetime :remember_created_at

      ## Trackable
      # t.integer  :sign_in_count, default: 0, null: false
      # t.datetime :current_sign_in_at
      # t.datetime :last_sign_in_at
      # t.string   :current_sign_in_ip
      # t.string   :last_sign_in_ip

      ## Confirmable
      t.string   :confirmation_token
      t.datetime :confirmed_at
      t.datetime :confirmation_sent_at
      # t.string   :unconfirmed_email # Only if using reconfirmable
      t.text :unconfirmed_email_ciphertext
      t.string :unconfirmed_email_bidx

      ## Lockable
      t.integer  :failed_attempts, default: 0, null: false # Only if lock strategy is :failed_attempts
      t.string   :unlock_token # Only if unlock strategy is :email or :both
      t.datetime :locked_at

      ## Invitable
      t.string     :invitation_token
      t.datetime   :invitation_created_at
      t.datetime   :invitation_sent_at
      t.datetime   :invitation_accepted_at
      t.integer    :invitation_limit
      t.references :invited_by, polymorphic: true, type: 'VARBINARY(26)'
      t.integer    :invitations_count, default: 0

      t.timestamps null: false

      t.index :email_bidx, unique: true
      t.index :unconfirmed_email_bidx, unique: true
      t.index :reset_password_token, unique: true
      t.index :confirmation_token, unique: true
      t.index :unlock_token, unique: true
      t.index :invitations_count
      t.index :invitation_token, unique: true
      t.index :invited_by_id
    end
  end
end
