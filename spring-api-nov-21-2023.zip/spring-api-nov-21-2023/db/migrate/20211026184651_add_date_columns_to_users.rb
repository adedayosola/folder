class AddDateColumnsToUsers < ActiveRecord::Migration[6.1]
  def change
    change_table :users, bulk: true do |t|
      t.datetime :first_visit_date, after: :locked_at
      t.datetime :enrollment_date, after: :locked_at
      t.datetime :privacy_accept_date, after: :locked_at
    end
  end
end
