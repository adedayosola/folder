class AddDeactivationDateToUsers < ActiveRecord::Migration[6.1]
  change_table :users, bulk: true do |t|
    t.datetime :deactivation_date, after: :privacy_accept_date
  end
end
