class CreatePeopleTable < ActiveRecord::Migration[6.0]
  def change
    create_table :people, id: false do |t|
      t.binary :id, limit: 26, primary_key: true
      t.string :title, null: false
      t.string :urge_type, null: false

      t.timestamps
    end
  end
end
