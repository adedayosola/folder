class AddAdditionalTextToLookups < ActiveRecord::Migration[6.1]
  def change
    change_table :locations, bulk: true do |t|
      t.string :additional_text, after: :title
    end

    change_table :activities, bulk: true do |t|
      t.string :additional_text, after: :name
    end
  end
end
