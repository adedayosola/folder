class CreateJournals < ActiveRecord::Migration[6.1]
  def change
    create_table :journals, id: false do |t|
      t.binary :id, limit: 26, primary_key: true

      t.string :journal_type

      t.references :user, type: :binary, limit: 26, foreign_key: true, null: false

      t.datetime :gambling_start_at
      t.datetime :gambling_end_at
      t.boolean :won_money, default: false, null: false
      t.integer :total_money
      t.integer :intensity

      t.boolean :substances_used, default: false, null: false
      t.boolean :urge_outcome, default: false, null: false

      # CSV Style fields of data for now
      t.text :location
      t.text :gambling_type
      t.text :feelings_before
      t.text :feelings_during
      t.text :feelings_after
      t.text :thoughts
      t.text :people
      t.text :activities

      t.timestamps
    end
  end
end
