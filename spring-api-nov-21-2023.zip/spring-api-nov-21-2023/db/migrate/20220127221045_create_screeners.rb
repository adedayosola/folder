class CreateScreeners < ActiveRecord::Migration[6.1]
  def change
    create_table :screeners, id: false do |t|
      t.binary :id, limit: 26, primary_key: true
      t.references :user, type: :binary, limit: 26, foreign_key: true, null: false

      t.string :screener_type, null: false

      t.integer :score

      t.timestamps
    end
  end
end
