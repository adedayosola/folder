class ChangeTotalMoneyToFloat < ActiveRecord::Migration[6.1]
  def up
    change_column :journals, :total_money, :decimal, precision: 12, scale: 2
  end

  def down
    change_column :journals, :total_money, :integer
  end
end
