class CreateDemographicSurveys < ActiveRecord::Migration[6.1]
  def change
    create_table :demographic_surveys, id: false do |t|
      t.binary :id, limit: 26, primary_key: true
      t.references :user, type: :binary, limit: 26, foreign_key: true, null: false

      t.string :age, null: false
      t.string :gender, null: false
      t.string :living_situation, null: false
      t.string :annual_net_income, null: false
      t.json :money_sources, null: false
      t.string :highest_education, null: false
      t.string :duration_in_canada, null: false
      t.json :race, null: false
      t.string :current_gambling_treatment, null: false

      t.timestamps
    end
  end
end
