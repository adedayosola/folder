class CreateGamesTable < ActiveRecord::Migration[6.0]
  def change
    create_table :games, id: false do |t|
      t.binary :id, limit: 26, primary_key: true
      t.string :title, null: false

      t.timestamps
    end
  end
end
