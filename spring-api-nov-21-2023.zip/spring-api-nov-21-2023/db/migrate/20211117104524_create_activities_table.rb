class CreateActivitiesTable < ActiveRecord::Migration[6.0]
  def change
    create_table :activities, id: false do |t|
      t.binary :id, limit: 26, primary_key: true
      t.string :name, null: false

      t.timestamps
    end
  end
end
