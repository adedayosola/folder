# loading all the seeds from the seeds directory one by one

Dir[Rails.root.join('db/seeds/*.rb')].each do |seed|
  puts "Seeding #{File.basename(seed)}"

  load seed
end
