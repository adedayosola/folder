Emotion.create([
                 {name: 'Excited', color: 'green'},
                 {name: 'Angry', color: 'red'},
                 {name: 'Sad', color: 'blue'},
                 {name: 'Happy', color: 'yellow'},
                 {name: 'Fearful', color: 'orange'},
                 {name: 'Ashamed', color: 'purple'},
                 {name: 'Anxious', color: 'grey'},
                 {name: 'Other', color: 'white'}
               ])
