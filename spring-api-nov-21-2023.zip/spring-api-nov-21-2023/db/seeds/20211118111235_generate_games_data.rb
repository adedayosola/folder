Game.create([
              {title: 'Poker'},
              {title: 'Slots/EGMs/VLTs'},
              {title: 'Stock Market'},
              {title: 'Lottery Games'},
              {title: 'Horse Racing'},
              {title: 'Sports Betting'},
              {title: 'Table Games other than Poker'},
              {title: 'Bingo'},
              {title: 'Other'}
            ])
