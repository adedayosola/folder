Location.create([{title: 'Home', urge_type: 'gambled,urge'},
                 {title: 'Work', urge_type: 'gambled,urge'},
                 {title: 'Gambling Venue', urge_type: 'gambled,urge',
                  additional_text: '(Casino, race track, gambling hall)'},
                 {title: 'Sporting Event', urge_type: 'gambled,urge'},
                 {title: 'Convenience Store', urge_type: 'gambled,urge'},
                 {title: 'Drinking Establishment', urge_type: 'gambled,urge'},
                 {title: 'Other', urge_type: 'gambled,urge'}])
