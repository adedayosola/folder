Person.create([
                {title: 'Nobody', urge_type: 'gambled, urge'},
                {title: 'Friends', urge_type: 'gambled, urge'},
                {title: 'Partner/Spouse', urge_type: 'gambled, urge'},
                {title: 'Sibling', urge_type: 'gambled, urge'},
                {title: 'Parent', urge_type: 'gambled, urge'},
                {title: 'Extended family', urge_type: 'gambled, urge'},
                {title: 'Child', urge_type: 'gambled, urge'},
                {title: 'Work colleagues', urge_type: 'gambled, urge'},
                {title: 'People I know at the casino', urge_type: 'gambled'},
                {title: 'Other', urge_type: 'gambled, urge'}
              ])
