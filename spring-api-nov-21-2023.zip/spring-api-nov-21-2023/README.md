# Purpose
The Spring app is a Gambling cessation mobile application. Spring uses CBT principles to deliver services to vulnerable groups that are looking to quit or reduce gambling and its impacts on their lives. This is the API written in Ruby on Rails

## Documents

*  [Project Charter](https://docs.google.com/document/d/1rT38EvVklAZKRLpIE40vEqoMXACxg6DHGk-PJd5cwis)
*  [Risk Charter](https://docs.google.com/document/d/18A3AIBQ4wTQMUYjBfYtY5QiecWjxthb2z2hngYJ1TeQ)
*  [Technical Analysis](https://docs.google.com/document/d/1eQN_nDNLq9K3UL8zRrmr_LgDiTN02vjcCwnw92eluR4)
*  [Maintenance Spreadsheet](https://docs.google.com/spreadsheets/d/1yhdziZDbnwQtdf-oYB4HNiK6JJeneXNJqWPwlVsRnYI/edit#gid=0)

## Third-Party Services

| Service   | Description                  | Owned By | Managed By |
|:----------|:-----------------------------|:---------|:-----------|
| Heroku    | website hosting in staging   | Tactica  | Tactica    |
| Sparkpost | sending emails in staging    | Tactica  | Tactica    |
| Sendgrid  | sending emails in production | Client   | Tactica    |

## Environment Setup

Install gems and node modules:

    bin/setup

## Running In Development

    bin/foreman

## Licenses

Watch the licenses used by dependencies.

    bin/check_licenses

To approve new license types:

    license_finder permitted_licenses add [License Name] --who [Your Full Name] --why [Reason for Approval]

To approve new packages (if their license is not auto detected):

    license_finder approvals add [Package Name] --who [Your Full Name] --why [Reason for Approval]

## Code Linting

    bin/lint

## Running Test Suite

    bin/rails test:system test

## Staging Deployment

This project is automatically deployed to Heroku any time a new code is merged into the `master` branch using Gitlab CI.

The staging environment requires a `LOCKBOX_MASTER_KEY` used by the lockbox gem in order to encrypt data. This key can be generated with:

    Lockbox.generate_key