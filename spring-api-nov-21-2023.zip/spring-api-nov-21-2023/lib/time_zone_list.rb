module TimeZoneList
  def self.for(country_code)
    ActiveSupport::TimeZone.country_zones(country_code)
  end
end
