require 'test_helper'

module Api
  class ErrorsControllerTest < ActionDispatch::IntegrationTest
    test 'should get 404' do
      get '/api/404'

      assert_response :not_found
      assert_template nil
    end
  end
end
