require 'test_helper'

class ErrorsControllerTest < ActionDispatch::IntegrationTest
  test 'should process GET for different formats' do
    errors.each do |error|
      formats.each do |format|
        get "#{error[:url]}.#{format}"

        assert_response error[:status]
        assert_template error[:status]
      end
    end
  end

  test 'should process POST for different formats' do
    errors.each do |error|
      formats.each do |format|
        post "#{error[:url]}.#{format}"

        assert_response error[:status]
        assert_template error[:status]
      end
    end
  end

  test 'should process PUT for different formats' do
    errors.each do |error|
      formats.each do |format|
        put "#{error[:url]}.#{format}"

        assert_response error[:status]
        assert_template error[:status]
      end
    end
  end

  test 'should process PATCH for different formats' do
    errors.each do |error|
      formats.each do |format|
        patch "#{error[:url]}.#{format}"

        assert_response error[:status]
        assert_template error[:status]
      end
    end
  end

  test 'should process DELETE for different formats' do
    errors.each do |error|
      formats.each do |format|
        delete "#{error[:url]}.#{format}"

        assert_response error[:status]
        assert_template error[:status]
      end
    end
  end

  private

  def errors
    [
      {url: '/401', status: :unauthorized},
      {url: '/404', status: :not_found},
      {url: '/500', status: :internal_server_error}
    ]
  end

  def formats
    %i[css gif html jpg js png ttf woff xml]
  end
end
