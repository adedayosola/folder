require 'test_helper'

class PagesControllerTest < ActionDispatch::IntegrationTest
  test 'should get home when not signed in' do
    get root_url

    assert_redirected_to new_admin_session_url
  end

  test 'should get home when signed in as an admin' do
    sign_in admins(:one)
    get root_url

    assert_redirected_to admins_url
  end
end
