require 'test_helper'

module DeviseOverrides
  class UnlocksControllerTest < ActionDispatch::IntegrationTest
    include DeviseHelper

    test 'should get new' do
      devise_mappings.each do |scope, _klass|
        next unless Devise.mappings[scope].lockable?

        get url_for([:new, scope, :unlock])

        assert_response :success
      end
    end

    test 'should create unlock' do
      devise_mappings.each do |scope, klass|
        next unless Devise.mappings[scope].lockable?

        klass.where.not(unlock_token: nil).each_with_index do |record, index|
          post url_for([scope, :unlock]), params: {"#{scope}": {email: record.email}}

          assert_redirected_to url_for([:new, scope, :session])
          assert_enqueued_emails index + 1
        end
      end
    end
  end
end
