require 'test_helper'

module DeviseOverrides
  class RegistrationsControllerTest < ActionDispatch::IntegrationTest
    include DeviseHelper

    test 'should get new for first resource' do
      devise_mappings.each do |scope, klass|
        next unless Devise.mappings[scope].registerable?

        klass.destroy_all
        get url_for([:new, scope, :registration])

        assert_response :success
      end
    end

    test 'should not get new for subsequent resources' do
      devise_mappings.each do |scope, _klass|
        next unless Devise.mappings[scope].registerable?

        get url_for([:new, scope, :registration])

        assert_redirected_to url_for([:new, scope, :session])
      end
    end

    test 'should create first resource' do
      devise_mappings.each do |scope, klass|
        next unless Devise.mappings[scope].registerable?

        klass.destroy_all

        assert_difference('klass.count') do
          post url_for([scope, :registration]), params: {"#{scope}": resource_params}
        end

        if klass.devise_modules.include?(:confirmable)
          assert_enqueued_emails 1
        else
          assert_no_enqueued_emails
        end
      end

      assert_redirected_to root_url
    end

    test 'should not create subsequent resources' do
      devise_mappings.each do |scope, _klass|
        next unless Devise.mappings[scope].registerable?

        post url_for([scope, :registration]), params: {"#{scope}": resource_params}

        assert_redirected_to url_for([:new, scope, :session])
      end
    end

    test 'should get edit' do
      devise_mappings.each do |scope, klass|
        next unless Devise.mappings[scope].registerable?

        able_to_sign_in(klass).each do |record|
          sign_in record
          get url_for([:edit, scope, :registration])

          assert_response :success
        end
      end
    end

    test 'should update resource' do
      devise_mappings.each do |scope, klass|
        next unless Devise.mappings[scope].registerable?

        enqueued_email_count = 0
        record = able_to_sign_in(klass).sample
        sign_in record
        patch url_for([scope, :registration]), params: {"#{scope}": resource_params}
        enqueued_email_count += 1 if klass.devise_modules.include?(:confirmable)
        enqueued_email_count += 1 if klass.send_password_change_notification
        enqueued_email_count += 1 if klass.send_email_changed_notification

        assert_enqueued_emails enqueued_email_count
        assert_redirected_to root_url
      end
    end
  end
end
