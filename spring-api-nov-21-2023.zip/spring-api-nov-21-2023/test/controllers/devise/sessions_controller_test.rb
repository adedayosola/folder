require 'test_helper'

module DeviseOverrides
  class SessionsControllerTest < ActionDispatch::IntegrationTest
    include DeviseHelper

    test 'should get new' do
      devise_mappings.each do |scope, _klass|
        get url_for([:new, scope, :session])

        assert_response :success
      end
    end

    test 'should create session' do
      devise_mappings.each do |scope, klass|
        able_to_sign_in(klass).each do |record|
          klass.authentication_keys.each do |auth_key|
            post url_for([scope, :session]), params: {"#{scope}": {
              "#{auth_key}": record.send(auth_key), password: 'MyC0mPl3xPassw0rd!'
            }}

            assert_redirected_to root_url
          end
        end
      end
    end

    test 'should destroy session' do
      devise_mappings.each do |scope, klass|
        able_to_sign_in(klass).each do |record|
          sign_in record
          delete url_for([:destroy, scope, :session])

          assert_redirected_to url_for([:new, scope, :session])
        end
      end
    end
  end
end
