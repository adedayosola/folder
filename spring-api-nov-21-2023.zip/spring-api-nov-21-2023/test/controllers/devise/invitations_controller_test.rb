require 'test_helper'

module DeviseOverrides
  class InvitationsControllerTest < ActionDispatch::IntegrationTest
    include DeviseHelper

    test 'should get new' do
      devise_mappings.each do |scope, klass|
        next unless Devise.mappings[scope].invitable?

        able_to_sign_in(klass).each do |record|
          sign_in record
          get url_for([:new, scope, :invitation])

          assert_response :success
        end
      end
    end

    test 'should create invitation' do
      devise_mappings.each do |scope, klass|
        next unless Devise.mappings[scope].invitable?

        able_to_sign_in(klass).each_with_index do |record, index|
          sign_in record
          post url_for([scope, :invitation]), params: {"#{scope}": {email: 'test@example.com'}}

          assert_enqueued_emails index + 1
          assert_redirected_to url_for([scope.to_s.pluralize.to_sym])
        end
      end
    end
  end
end
