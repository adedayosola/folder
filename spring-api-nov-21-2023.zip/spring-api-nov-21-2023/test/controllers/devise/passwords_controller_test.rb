require 'test_helper'

module DeviseOverrides
  class PasswordsControllerTest < ActionDispatch::IntegrationTest
    include DeviseHelper

    test 'should get new' do
      devise_mappings.each do |scope, _klass|
        next unless Devise.mappings[scope].recoverable?

        get url_for([:new, scope, :password])

        assert_response :success
      end
    end

    test 'should create password reset token' do
      devise_mappings.each do |scope, klass|
        klass.all.each_with_index do |record, index|
          next unless Devise.mappings[scope].recoverable?

          post url_for([scope, :password]), params: {"#{scope}": {email: record.email}}

          assert_not_nil klass.find(record.id).reset_password_token
          assert_enqueued_emails index + 1
          assert_redirected_to url_for([:new, scope, :session])
        end
      end
    end

    test 'should get edit' do
      devise_mappings.each do |scope, _klass|
        next unless Devise.mappings[scope].recoverable?

        get url_for([:edit, scope, :password, {reset_password_token: 'token'}])

        assert_response :success
      end
    end

    test 'should update password' do
      devise_mappings.each do |scope, klass|
        next unless Devise.mappings[scope].recoverable?

        klass.find_each do |record|
          patch url_for([scope, :password]), params: {"#{scope}": {
            reset_password_token: record.send_reset_password_instructions,
            password: 'NewC0mPl3xPassw0rd!', password_confirmation: 'NewC0mPl3xPassw0rd!'
          }}

          assert_not_equal record.encrypted_password, klass.find(record.id).encrypted_password
          assert_redirected_to url_for([:new, scope, :session])
        end
      end
    end
  end
end
