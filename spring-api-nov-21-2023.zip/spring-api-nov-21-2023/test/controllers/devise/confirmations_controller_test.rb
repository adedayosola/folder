require 'test_helper'

module DeviseOverrides
  class ConfirmationsControllerTest < ActionDispatch::IntegrationTest
    include DeviseHelper

    test 'should get new' do
      devise_mappings.each do |scope, _klass|
        next unless Devise.mappings[scope].confirmable?

        get url_for([:new, scope, :confirmation])

        assert_response :success
      end
    end

    test 'should create confirmation for' do
      devise_mappings.each do |scope, klass|
        next unless Devise.mappings[scope].confirmable?

        klass.where(confirmed_at: nil).each_with_index do |record, index|
          post url_for([scope, :confirmation]), params: {"#{scope}": {email: record.email}}

          assert_enqueued_emails index + 1
          assert_redirected_to url_for([:new, scope, :session])
        end
      end
    end
  end
end
