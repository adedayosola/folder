require 'test_helper'

class AdminTest < ActiveSupport::TestCase
  test 'valid admin' do
    Admin.find_each do |admin|
      assert_predicate admin, :valid?
    end
  end

  test 'should reject an empty record' do
    admin = Admin.new

    assert_not admin.valid?
    assert_includes admin.errors[:first_name], "can't be blank"
    assert_includes admin.errors[:last_name], "can't be blank"
    assert_includes admin.errors[:time_zone], 'is not included in the list'
    assert_includes admin.errors[:email], "can't be blank"
  end

  test 'should reject an invalid email' do
    admin = Admin.new(email: 'test@myemailis@invalid.com')

    assert_not admin.valid?
    assert_includes admin.errors[:email], 'is invalid'
  end
end
