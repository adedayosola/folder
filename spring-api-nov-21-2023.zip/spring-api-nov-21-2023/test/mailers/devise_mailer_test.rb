require 'test_helper'

class DeviseMailerTest < ActionMailer::TestCase
  include DeviseHelper

  test 'send confirmation instructions for new account' do
    devise_mappings.each do |scope, klass|
      next unless Devise.mappings[scope].confirmable?

      record = klass.where(confirmed_at: nil).sample

      assert_not_nil record
      mail = DeviseMailer.confirmation_instructions(record, 'faketoken')

      assert_equal I18n.t('devise.mailer.confirmation_instructions.subject'), mail.subject
      assert_equal [record.email], mail.to
      assert_equal [CONFIG[:email_address]], mail.from
      assert_match I18n.t('devise.mailer.confirmation_instructions.new.title',
                          app_name: I18n.t('app_name')), mail.body.encoded
    end
  end

  test 'send confirmation instructions on email change' do
    devise_mappings.each do |scope, klass|
      next unless Devise.mappings[scope].confirmable?

      record = klass.where.not(confirmed_at: nil).sample

      assert_not_nil record
      mail = DeviseMailer.confirmation_instructions(record, 'faketoken')

      assert_equal I18n.t('devise.mailer.confirmation_instructions.subject'), mail.subject
      assert_equal [record.email], mail.to
      assert_equal [CONFIG[:email_address]], mail.from
      assert_match I18n.t('devise.mailer.confirmation_instructions.changed.title'), mail.body.encoded
    end
  end

  test 'send email is changed notification' do
    devise_mappings.each do |scope, klass|
      next unless Devise.mappings[scope].confirmable?

      record = klass.where(unconfirmed_email: nil).sample

      assert_not_nil record
      mail = DeviseMailer.email_changed(record)

      assert_equal I18n.t('devise.mailer.email_changed.subject'), mail.subject
      assert_equal [record.email], mail.to
      assert_equal [CONFIG[:email_address]], mail.from
      assert_match I18n.t('devise.mailer.email_changed.confirmed.title'), mail.body.encoded
    end
  end

  test 'send email changing notification' do
    devise_mappings.each do |scope, klass|
      next unless Devise.mappings[scope].confirmable?

      record = klass.where.not(unconfirmed_email: nil).sample

      assert_not_nil record
      mail = DeviseMailer.email_changed(record)

      assert_equal I18n.t('devise.mailer.email_changed.subject'), mail.subject
      assert_equal [record.email], mail.to
      assert_equal [CONFIG[:email_address]], mail.from
      assert_match I18n.t('devise.mailer.email_changed.unconfirmed.title'), mail.body.encoded
    end
  end

  test 'send invitation' do
    devise_mappings.each do |scope, klass|
      next unless Devise.mappings[scope].invitable?

      record = klass.all.sample
      mail = DeviseMailer.invitation_instructions(record, 'faketoken')

      assert_equal I18n.t('devise.mailer.invitation_instructions.subject'), mail.subject
      assert_equal [record.email], mail.to
      assert_equal [CONFIG[:email_address]], mail.from
      assert_match I18n.t('devise.mailer.invitation_instructions.message'), mail.body.encoded
    end
  end

  test 'send password change notification' do
    devise_mappings.each do |scope, klass|
      next unless Devise.mappings[scope].recoverable?

      record = klass.all.sample
      mail = DeviseMailer.password_change(record)

      assert_equal I18n.t('devise.mailer.password_change.subject'), mail.subject
      assert_equal [record.email], mail.to
      assert_equal [CONFIG[:email_address]], mail.from
      assert_match I18n.t('devise.mailer.password_change.message',
                          app_name: I18n.t('app_name')), mail.body.encoded
    end
  end

  test 'send reset password instructions' do
    devise_mappings.each do |scope, klass|
      next unless Devise.mappings[scope].recoverable?

      record = klass.all.sample
      mail = DeviseMailer.reset_password_instructions(record, 'faketoken')

      assert_equal I18n.t('devise.mailer.reset_password_instructions.subject'), mail.subject
      assert_equal [record.email], mail.to
      assert_equal [CONFIG[:email_address]], mail.from
      assert_match I18n.t('devise.mailer.reset_password_instructions.message',
                          app_name: I18n.t('app_name')), mail.body.encoded
    end
  end

  test 'send unlock instructions' do
    devise_mappings.each do |scope, klass|
      next unless Devise.mappings[scope].lockable?

      record = klass.all.sample
      mail = DeviseMailer.unlock_instructions(record, 'faketoken')

      assert_equal I18n.t('devise.mailer.unlock_instructions.subject'), mail.subject
      assert_equal [record.email], mail.to
      assert_equal [CONFIG[:email_address]], mail.from
      assert_match I18n.t('devise.mailer.unlock_instructions.account_locked',
                          app_name: I18n.t('app_name')), mail.body.encoded
    end
  end
end
