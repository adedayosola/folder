# Preview all emails at http://localhost:3000/rails/mailers/devise_mailer

class DeviseMailerPreview < ActionMailer::Preview
  # Preview this email at http://localhost:3000/rails/mailers/devise_mailer/confirmation_instructions_new_account
  def confirmation_instructions_new_account
    DeviseMailer.confirmation_instructions(Admin.where(confirmed_at: nil).sample, 'faketoken')
  end

  # Preview this email at http://localhost:3000/rails/mailers/devise_mailer/confirmation_instructions_new_email
  def confirmation_instructions_new_email
    DeviseMailer.confirmation_instructions(Admin.where.not(confirmed_at: nil).sample, 'faketoken')
  end

  # Preview this email at http://localhost:3000/rails/mailers/devise_mailer/email_changed
  def email_changed
    DeviseMailer.email_changed(Admin.where(unconfirmed_email: nil).sample)
  end

  # Preview this email at http://localhost:3000/rails/mailers/devise_mailer/email_changing
  def email_changing
    DeviseMailer.email_changed(Admin.where.not(unconfirmed_email: nil).sample)
  end

  # Preview this email at http://localhost:3000/rails/mailers/devise_mailer/invitation_instructions
  def invitation_instructions
    DeviseMailer.invitation_instructions(Admin.all.sample, 'faketoken')
  end

  # Preview this email at http://localhost:3000/rails/mailers/devise_mailer/password_change
  def password_change
    DeviseMailer.password_change(Admin.all.sample)
  end

  # Preview this email at http://localhost:3000/rails/mailers/devise_mailer/reset_password_instructions
  def reset_password_instructions
    DeviseMailer.reset_password_instructions(Admin.all.sample, 'faketoken')
  end

  # Preview this email at http://localhost:3000/rails/mailers/devise_mailer/unlock_instructions
  def unlock_instructions
    DeviseMailer.unlock_instructions(Admin.all.sample, 'faketoken')
  end
end
