# module AuthorizationHelper
#   def auth_tokens_for_user(user)
#     post api_user_session_url, as: :json, params: {uid: user.uid, password: user.uid}
#     assert_response :success
#     response.headers.slice('client', 'access-token', 'uid')
#   end
# end

module AuthorizationHelper
  def auth_tokens_for_user(user)
    post api_user_session_url,
         params: {uid: user.uid, password: user.uid}
    response.headers.slice('client', 'access-token', 'uid')
  end
end
