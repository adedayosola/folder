module DeviseHelper
  def devise_mappings
    mappings = {}
    Devise.mappings.each do |scope|
      klass = scope[0].to_s.classify.safe_constantize
      next if scope[1].path.include? 'auth'
      next if klass.new.respond_to?(:tokens?)

      mappings[scope[0]] = klass
    end
    mappings
  end

  def able_to_sign_in(klass)
    record = klass.new
    if record.respond_to?(:confirmed_at) && record.respond_to?(:enabled) && record.respond_to?(:unlock_token)
      klass.where.not(confirmed_at: nil).where(enabled: true, unlock_token: nil)
    else
      klass.all
    end
  end

  def resource_params
    {
      first_name: 'Test', last_name: 'Test', time_zone: TimeZoneList.for('CA').sample.tzinfo.name,
      email: 'new@example.com', current_password: 'MyC0mPl3xPassw0rd!',
      password: 'NewC0mPl3xPassw0rd!', password_confirmation: 'NewC0mPl3xPassw0rd!'
    }
  end
end
