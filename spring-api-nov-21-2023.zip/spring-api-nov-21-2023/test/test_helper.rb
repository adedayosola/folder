ENV['RAILS_ENV'] ||= 'test'
require_relative '../config/environment'
require 'rails/test_help'
require 'helpers/devise_helper'
require 'helpers/authorization_helper'

module ActiveSupport
  class TestCase
    include Devise::Test::IntegrationHelpers
    include AuthorizationHelper

    # Run tests in parallel with specified workers
    # parallelize(workers: :number_of_processors)

    # Setup all fixtures in test/fixtures/*.yml for all tests in alphabetical order.
    fixtures :all

    # Add more helper methods to be used by all tests here...
    def fill_in_trix_editor(id, with:)
      find(:xpath, "//trix-editor[@input='#{id}']").click.set(with)
    end
  end
end
