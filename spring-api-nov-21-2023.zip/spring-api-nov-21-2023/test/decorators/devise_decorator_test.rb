require 'test_helper'

class DeviseDecoratorTest < Draper::TestCase
  include DeviseHelper

  test 'should get active' do
    devise_mappings.each do |_scope, klass|
      next unless klass.new.respond_to? :enabled?

      DeviseDecorator.decorate_collection(klass.all).each do |record|
        assert_equal record.confirmed? && record.enabled?, record.active?
      end
    end
  end

  test 'should get full name' do
    devise_mappings.each do |_scope, klass|
      next unless klass.respond_to? :full_name

      DeviseDecorator.decorate_collection(klass.all).each do |record|
        assert_equal "#{record.first_name} #{record.last_name}", record.full_name
      end
    end
  end

  test 'should get initials' do
    devise_mappings.each do |_scope, klass|
      next unless klass.respond_to? :full_name

      DeviseDecorator.decorate_collection(klass.all).each do |record|
        assert_equal "#{record.first_name[0]}#{record.last_name[0]}".upcase, record.initials
      end
    end
  end

  test 'should get status' do
    devise_mappings.each do |scope, klass|
      DeviseDecorator.decorate_collection(klass.all).each do |record|
        if record.respond_to?(:enabled?) && !record.enabled?
          assert_match I18n.t('resource.status.disabled'), record.status(authenticated: false)
        elsif Devise.mappings[scope].invitable? && record.invited_to_sign_up?
          assert_match I18n.t('resource.status.invited'), record.status(authenticated: false)
        elsif Devise.mappings[scope].confirmable? && !record.confirmed?
          assert_match I18n.t('resource.status.unconfirmed'), record.status(authenticated: false)
        elsif Devise.mappings[scope].lockable? && record.access_locked?
          assert_match I18n.t('resource.status.locked'), record.status(authenticated: false)
        else
          assert_nil record.status(authenticated: false)
        end
      end
    end
  end
end
