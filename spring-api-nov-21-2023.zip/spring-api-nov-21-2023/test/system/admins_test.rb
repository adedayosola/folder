require 'application_system_test_case'

class AdminsTest < ApplicationSystemTestCase
  setup do
    @admin = admins(:one)
    sign_in @admin
  end

  test 'visiting the index' do
    visit admins_url

    Admin.where.not(id: @admin.id).find_each do |admin|
      assert_selector 'small', text: admin.email
    end
    refute_selector 'small', text: @admin.email
    assert_selector 'h1', text: 'Admins'
  end

  test 'visiting create new admin' do
    visit admins_url
    click_link 'New Admin'

    assert_selector 'h2', text: 'Create New Admin'
  end

  test 'update profile' do
    visit root_url
    find('nav .avatar').click
    click_link 'My Profile'
    click_link 'Update Profile'
    fill_in 'Current password', with: 'MyC0mPl3xPassw0rd!'
    click_button 'Update Profile'

    assert_text I18n.t('devise.registrations.updated')
  end

  test 'destroying an admin' do
    visit admins_url
    find('tr.link', match: :first)
    page.accept_confirm do
      click_link 'Delete', match: :first
    end

    assert_text 'Admin was successfully destroyed.'
  end

  test 'destroying own account' do
    visit profile_url
    page.accept_confirm do
      click_link 'Delete Account'
    end

    assert_text I18n.t('devise.registrations.destroyed')
  end
end
