require 'application_system_test_case'

class DeviseTest < ApplicationSystemTestCase
  include DeviseHelper

  test 'sign up' do
    devise_mappings.each do |scope, klass|
      next unless Devise.mappings[scope].registerable?

      klass.destroy_all
      visit url_for([:new, scope, :registration])
      fill_in 'First name', with: 'Test'
      fill_in 'Last name', with: 'Test'
      fill_in 'Email', with: 'test@example.com'
      find("option[value='#{TimeZoneList.for('CA').sample.tzinfo.name}']", match: :first).click
      fill_in 'Password', with: 'MyC0mPl3xPassw0rd!'
      fill_in 'Password confirmation', with: 'MyC0mPl3xPassw0rd!'
      click_button I18n.t('devise.registrations.new.submit')

      assert_text I18n.t('devise.registrations.signed_up_but_unconfirmed')
    end
  end

  test 'sign in and sign out' do
    devise_mappings.each do |scope, klass|
      able_to_sign_in(klass).each do |record|
        klass.authentication_keys.each do |auth_key|
          visit url_for([:new, scope, :session])
          fill_in auth_key.to_s.titlecase, with: record.send(auth_key)
          fill_in 'Password', with: 'MyC0mPl3xPassw0rd!'
          click_button I18n.t('devise.sessions.new.submit')

          assert_text I18n.t('devise.sessions.signed_in')
          find('nav .avatar').click
          click_link 'Sign Out'

          assert_text I18n.t('devise.sessions.signed_out')
        end
      end
    end
  end

  test 'should not sign in when account is unconfirmed' do
    devise_mappings.each do |scope, klass|
      next unless Devise.mappings[scope].confirmable?

      record = klass.where(confirmed_at: nil).where(invitation_token: nil).sample
      visit url_for([:new, scope, :session])
      fill_in 'Email', with: record.email
      fill_in 'Password', with: 'MyC0mPl3xPassw0rd!'
      click_button I18n.t('devise.sessions.new.submit')

      assert_text I18n.t('devise.failure.unconfirmed')
    end
  end

  test 'should not sign in when account is disabled' do
    devise_mappings.each do |scope, klass|
      next unless klass.new.respond_to? :enabled

      record = klass.where(enabled: false).sample
      visit url_for([:new, scope, :session])
      fill_in 'Email', with: record.email
      fill_in 'Password', with: 'MyC0mPl3xPassw0rd!'
      click_button I18n.t('devise.sessions.new.submit')

      assert_text I18n.t('devise.failure.inactive')
    end
  end

  test 'send reset password instructions' do
    devise_mappings.each do |scope, klass|
      next unless Devise.mappings[scope].recoverable?

      record = klass.all.sample
      visit url_for([:new, scope, :session])
      click_link('Forgot your password?') and sleep(0.5)
      fill_in 'Email', with: record.email
      click_button I18n.t('devise.passwords.new.submit')

      assert_text I18n.t('devise.passwords.send_paranoid_instructions')
    end
  end

  # test 'send confirmation instructions' do
  #   devise_mappings.each do |scope, klass|
  #     next unless Devise.mappings[scope].confirmable?
  #
  #     record = klass.all.sample
  #     visit url_for([:new, scope, :session])
  #     click_link("Didn't receive confirmation instructions?") and sleep(0.5)
  #     fill_in 'Email', with: record.email
  #     click_button I18n.t('devise.confirmations.new.submit')
  #     assert_text I18n.t('devise.confirmations.send_paranoid_instructions')
  #   end
  # end

  test 'send unlock instructions' do
    devise_mappings.each do |scope, klass|
      next unless Devise.mappings[scope].lockable?

      record = klass.all.sample
      visit url_for([:new, scope, :session])
      click_link("Didn't receive unlock instructions?") and sleep(0.5)
      fill_in 'Email', with: record.email
      click_button I18n.t('devise.unlocks.new.submit')

      assert_text I18n.t('devise.unlocks.send_paranoid_instructions')
    end
  end

  test 'should invite someone' do
    devise_mappings.each do |scope, klass|
      next unless Devise.mappings[scope].invitable?

      able_to_sign_in(klass).each do |record|
        sign_in record
        visit url_for([:new, scope, :invitation])
        fill_in 'Email', with: 'test@example.com'
        click_button I18n.t('devise.invitations.new.submit')

        assert_text I18n.t('devise.invitations.send_instructions', email: 'test@example.com')
        sign_out record
      end
    end
  end
end
