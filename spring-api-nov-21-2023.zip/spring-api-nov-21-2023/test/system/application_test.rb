require 'application_system_test_case'

class ApplicationTest < ApplicationSystemTestCase
  test 'should get favicon' do
    visit root_url

    assert_predicate all('link[rel*="icon"]', visible: :any).size, :positive?
    all('link[rel*="icon"]', visible: :any).each { |icon| visit icon[:href] }
  end

  test 'should get manifest' do
    visit root_url
    visit find('link[rel="manifest"]', visible: :any)[:href]
  end
end
