import React from 'react';
import Notifications from 'react-notify-toast';

const ToastNotifications = () =>
  <Notifications options={{zIndex: 999999}}/>;

export default ToastNotifications;