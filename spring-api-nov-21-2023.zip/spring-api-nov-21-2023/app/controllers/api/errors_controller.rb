module Api
  class ErrorsController < ApplicationController
    skip_before_action :authenticate_api_user!

    def not_found
      head :not_found
    end
  end
end
