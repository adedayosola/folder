module Api
  class DemographicSurveysController < ApplicationController
    def create
      return if current_api_user.demographic_survey

      @demographic_survey = current_api_user.build_demographic_survey(screener_params)
      if @demographic_survey.save
        head :created
      else
        render json: @demographic_survey.errors, status: :unprocessable_entity
      end
    end

    private

    def screener_params
      params.permit(:age, :gender, :living_situation, :annual_net_income, :money_sources, :highest_education,
                    :duration_in_canada, :race, :current_gambling_treatment)
    end
  end
end
