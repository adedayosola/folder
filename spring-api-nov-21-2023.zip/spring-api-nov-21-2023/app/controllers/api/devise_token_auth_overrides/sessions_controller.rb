module Api
  module DeviseTokenAuthOverrides
    class SessionsController < DeviseTokenAuth::SessionsController
      before_action :set_hidden_params

      def find_resource(field, value)
        @resource = resource_class.dta_find_by(field => value, provider: field)
      end

      def create
        super
        return unless api_user_signed_in?

        @resource.update(first_visit_date: Time.current) if @resource.first_visit_date.nil?
      end

      protected

      # this fixes a bug in devise_token_auth which assumes that if a record cannot login
      # with valid credentials, it is always because the record is not confirmed
      def render_create_error_not_confirmed
        if @resource.active?
          render_error(401, I18n.t('devise_token_auth.sessions.bad_credentials', email: @resource.email))
        else
          render_error(401, I18n.t('devise.failure.inactive'))
        end
      end

      def render_create_success
        render partial: 'api/users/user', locals: {user: @resource}
      end

      def render_create_error_account_locked
        render_error(401, I18n.t('devise_token_auth.sessions.bad_credentials'))
      end

      # obfuscate the login parameters
      def set_hidden_params
        params[:email] = params.delete(:val1) if params[:val1]
        params[:password] = params.delete(:val2) if params[:val2]
      end
    end
  end
end
