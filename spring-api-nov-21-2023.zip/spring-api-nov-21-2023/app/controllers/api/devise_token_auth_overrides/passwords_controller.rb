module Api
  module DeviseTokenAuthOverrides
    class PasswordsController < DeviseTokenAuth::PasswordsController
      before_action :set_hidden_params

      def find_resource(field, value)
        @resource = resource_class.dta_find_by(field => value, provider:)
      end

      def render_create_success
        render json: {
          message: success_message('passwords', @email)
        }
      end

      def render_error(_, _, _ = nil)
        render json: {
          message: success_message('passwords', @email)
        }
      end

      protected

      # obfuscate the login parameters
      def set_hidden_params
        params[:email] = params.delete(:val1) if params[:val1]
      end
    end
  end
end
