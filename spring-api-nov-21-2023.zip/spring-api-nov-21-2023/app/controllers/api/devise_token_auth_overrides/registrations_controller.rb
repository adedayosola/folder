module Api
  module DeviseTokenAuthOverrides
    class RegistrationsController < DeviseTokenAuth::RegistrationsController
      before_action :set_hidden_params

      def render_create_success
        render partial: 'api/users/user', locals: {user: @resource}
      end

      def render_update_success
        render partial: 'api/users/user', locals: {user: @resource}
      end

      def render_create_error
        render json: {
          status: 'error',
          errors: {full_messages: ['There was an error creating your account.']}
        }, status: :unprocessable_entity
      end

      protected

      # obfuscate the login parameters for registration && changing password
      def set_hidden_params # rubocop:disable Metrics/AbcSize
        params[:email] = params.delete(:val1) if params[:val1]
        params[:password] = params.delete(:val2) if params[:val2]
        params[:password_confirmation] = params.delete(:val3) if params[:val3]
        params[:current_password] = params.delete(:val4) if params[:val4]
      end
    end
  end
end
