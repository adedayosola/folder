module Api
  class UsersController < ApplicationController
    before_action :set_user

    def subscribe_enrollment
      @user.enrollment_date = Time.current if @user.enrollment_date.nil?
      save_and_render
    end

    def unsubscribe_enrollment
      @user.active = false
      @user.deactivation_date = Time.current if @user.deactivation_date.nil?
      save_and_render
    end

    def accept_privacy_policy
      @user.privacy_accept_date = Time.current if @user.privacy_accept_date.nil?
      save_and_render
    end

    private

    def set_user
      @user = current_api_user
    end

    def save_and_render
      if @user.save
        render partial: 'api/users/user', locals: {user: @user}
      else
        render json: {errors: @user.errors}
      end
    end
  end
end
