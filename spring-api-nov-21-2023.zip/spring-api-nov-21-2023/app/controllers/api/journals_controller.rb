module Api
  class JournalsController < ApplicationController
    def index
      render partial: 'api/journals/journals', locals: {journals: current_api_user&.journals}, status: :ok
    end

    def create
      @journal = current_api_user.journals.new(journal_params)
      if @journal.save
        render partial: 'api/journals/journals', locals: {journals: current_api_user&.journals}, status: :created
      else
        render json: @journal.errors, status: :unprocessable_entity
      end
    end

    def update
      @journal = current_api_user.journals.find(params[:id])
      if @journal.update(journal_params)
        render partial: 'api/journals/journals', locals: {journals: current_api_user&.journals}, status: :ok
      else
        render json: @journal.errors, status: :unprocessable_entity
      end
    end

    def destroy
      @journal = current_api_user.journals.find(params[:id])
      if @journal.destroy
        render partial: 'api/journals/journals', locals: {journals: current_api_user&.journals}, status: :ok
      else
        render json: @journal.errors, status: :unprocessable_entity
      end
    end

    private

    def journal_params
      params.permit(:substances_used, :journal_type, :location, :gambling_type, :feelings_before,
                    :feelings_during, :feelings_after, :thoughts, :people, :activities,
                    :gambling_start_at, :gambling_end_at, :won_money, :total_money, :intensity, :urge_outcome)
    end
  end
end
