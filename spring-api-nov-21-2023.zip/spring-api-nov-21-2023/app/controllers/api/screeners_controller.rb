module Api
  class ScreenersController < ApplicationController
    def index
      render partial: 'api/screeners/screeners', locals: {
        screeners: current_api_user.screeners.order('created_at desc')
      }, status: :ok
    end

    def create
      @screener = current_api_user.screeners.new(screener_params)
      if @screener.save
        render partial: 'api/screeners/screener', locals: {screener: @screener}, status: :created
      else
        render json: @screener.errors, status: :unprocessable_entity
      end
    end

    private

    def screener_params
      params.permit(:screener_type, :score)
    end
  end
end
