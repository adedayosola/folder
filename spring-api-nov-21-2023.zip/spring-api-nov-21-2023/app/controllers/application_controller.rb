require_relative 'concerns/devise_configuration'

class ApplicationController < ActionController::Base
  include HttpErrorHandler
  include DeviseConfiguration
  skip_before_action :verify_authenticity_token, if: :api_controller?
  # before_action :basic_auth, if: :basic_auth_enabled?
  before_action :authenticate_admin!, unless: :api_controller?
  before_action :forbid_public_admin_sign_up, unless: :api_controller?
  around_action :user_time_zone, unless: :api_controller?

  helper_method :no_admins?

  def admin_exists?
    admin_signed_in? || Admin.exists?
  end

  def no_admins?
    !admin_exists?
  end

  private

  def user_time_zone(&)
    Time.use_zone(current_admin&.time_zone || Time.zone.name, &)
  end

  def api_controller?
    request.path.include? '/api/'
  end

  def basic_auth_enabled?
    Rails.env.staging? && !api_controller?
  end

  def basic_auth
    username = Rails.application.credentials[Rails.env.to_sym][:basic_auth_username]
    password = Rails.application.credentials[Rails.env.to_sym][:basic_auth_password]
    authenticate_or_request_with_http_basic do |u, p|
      u == username && p == password
    end
  end
end
