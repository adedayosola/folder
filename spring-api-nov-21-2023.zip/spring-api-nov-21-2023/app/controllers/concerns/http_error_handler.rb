module HttpErrorHandler
  extend ActiveSupport::Concern

  included do
    rescue_from ActiveRecord::RecordNotFound, with: :not_found
    rescue_from ActionController::InvalidAuthenticityToken, with: :unauthorized
  end

  def not_found
    render template: 'errors/not_found', status: :not_found, formats: [:html]
  end

  def unauthorized
    render template: 'errors/unauthorized', status: :unauthorized
  end
end
