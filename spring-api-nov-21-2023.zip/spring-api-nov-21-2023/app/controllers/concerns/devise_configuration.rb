module DeviseConfiguration
  extend ActiveSupport::Concern

  included do
    before_action :configure_permitted_parameters, if: :devise_controller?

    # tells devise to accept custom database attributes
    def configure_permitted_parameters
      added_attrs = %i[first_name last_name time_zone]
      devise_parameter_sanitizer.permit :accept_invitation, keys: added_attrs
      devise_parameter_sanitizer.permit :sign_up, keys: added_attrs + %i[val1 val2]
      devise_parameter_sanitizer.permit :account_update, keys: added_attrs + %i[val1 val2 val3 val4]
    end

    protected

    def after_invite_path_for(_inviter, _invitee = nil)
      [resource_name.to_s.pluralize.to_sym]
    end

    private

    def forbid_public_admin_sign_up
      if admin_exists?
        if is_a?(Devise::RegistrationsController) && resource_name == :admin && %w[new create].include?(action_name)
          redirect_to url_for(%i[new admin session])
        end
      elsif !is_a? Devise::RegistrationsController
        redirect_to url_for(%i[new admin registration])
      end
    end

    # redirect devise user to their sign in page after log out
    def after_sign_out_path_for(resource_or_scope)
      [:new, resource_or_scope, :session]
    end
  end
end
