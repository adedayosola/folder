class AdminsController < ApplicationController
  before_action :set_admin, only: %i[resend_invitation destroy]

  def index
    @admins = DeviseDecorator.decorate_collection(Admin.order(:created_at).where.not(id: current_admin.id))
  end

  def show; end

  def resend_invitation
    @admin.deliver_invitation
    redirect_to admins_url, notice: t('devise.invitations.send_instructions', email: @admin.email)
  end

  def destroy
    if @admin.destroy
      redirect_to admins_url, notice: 'Admin was successfully destroyed.' # rubocop:disable Rails/I18nLocaleTexts
    else
      redirect_to admins_url, alert: @admin.errors.full_messages.to_sentence
    end
  end

  private

  def set_admin
    @admin = Admin.find(params[:id])
  end
end
