class ExportsController < ApplicationController
  def all
    export = Export.new
    if export.errors.any?
      redirect_back alert: export.errors.join('; '), fallback_location: admins_url
    else
      send_data export.zip, filename: "spring-export-#{Date.current}.zip"
    end
  end
end
