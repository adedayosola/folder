module DeviseOverrides
  class PasswordsController < Devise::PasswordsController
    def success; end

    protected

    def after_resetting_password_path_for(_resource)
      [resource_name, :password, :success]
    end
  end
end
