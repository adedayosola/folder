module DeviseOverrides
  class ConfirmationsController < Devise::ConfirmationsController
    def show # rubocop:disable Metrics/AbcSize
      self.resource = resource_class.confirm_by_token(params[:confirmation_token])
      yield resource if block_given?

      if resource.errors.empty?
        set_flash_message!(:notice, :confirmed, now: true)
        respond_with_navigational(resource) { render :success }
      else
        flash.now[:alert] = resource.errors.full_messages.to_sentence
        respond_with_navigational(resource.errors) { render :failure }
      end
    end

    def success; end

    def failure; end
  end
end
