module DeviseOverrides
  class UnlocksController < Devise::UnlocksController
    def success; end

    def after_unlock_path_for(_resource)
      user_unlock_success_path
    end
  end
end
