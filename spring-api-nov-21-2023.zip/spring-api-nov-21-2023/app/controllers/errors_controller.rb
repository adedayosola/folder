class ErrorsController < ApplicationController
  skip_before_action :authenticate_admin!
  around_action :set_error_template_and_status

  private

  def set_error_template_and_status
    respond_to do |format|
      format.json { head action_name.to_sym }
      format.any { render action_name, status: action_name.to_sym, formats: [:html] }
    end
  end
end
