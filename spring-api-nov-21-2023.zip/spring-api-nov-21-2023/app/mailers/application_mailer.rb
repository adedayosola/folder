class ApplicationMailer < ActionMailer::Base
  default from: "#{CONFIG[:email_header]} <#{CONFIG[:email_address]}>"
  layout 'mailer'
end
