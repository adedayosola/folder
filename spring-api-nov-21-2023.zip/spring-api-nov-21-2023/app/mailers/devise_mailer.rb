class DeviseMailer < Devise::Mailer
  layout 'mailer'
end
