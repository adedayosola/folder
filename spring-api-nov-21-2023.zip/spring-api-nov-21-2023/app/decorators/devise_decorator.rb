class DeviseDecorator < ApplicationDecorator
  decorates :admin
  delegate_all

  def active?
    confirmed? && (respond_to?(:enabled) ? enabled? : true)
  end

  def full_name
    "#{first_name} #{last_name}".strip
  end

  def initials
    ("#{first_name&.first}#{last_name&.first}".presence || email[0..1]).upcase
  end

  def status(authenticated: true) # rubocop:disable Metrics/AbcSize, Metrics/CyclomaticComplexity, Metrics/MethodLength, Metrics/PerceivedComplexity
    if authenticated && current_admin == self
      tag.span t('resource.status.self'), class: 'warning label'
    elsif respond_to?(:enabled?) && !enabled?
      tag.span t('resource.status.disabled'), class: 'secondary label'
    elsif devise_modules.include?(:invitable) && try(:invited_to_sign_up?)
      tag.span t('resource.status.invited'), class: 'primary label'
    elsif devise_modules.include?(:confirmable) && !confirmed?
      tag.span t('resource.status.unconfirmed'), class: 'warning label'
    elsif devise_modules.include?(:lockable) && access_locked?
      tag.span t('resource.status.locked'), class: 'warning label'
    end
  end
end
