class ApplicationDecorator < Draper::Decorator
  include Draper::LazyHelpers
end
