/*
 * = link_tree ../images
 * = link application.js
 * = link_directory ../stylesheets .css
 */