module LayoutHelper
  def align_center(&)
    tag.div class: 'grid-x align-center' do
      tag.div class: 'small-12 medium-6 large-4 cell' do
        capture(&)
      end
    end
  end
end
