module ButtonsHelper
  def new_button(path, model, classes: [])
    link_to fa_icon('plus', text: "New #{model}"), path, class: %w[success button] + classes
  end

  def cancel_button(path: nil, classes: [])
    link_to fa_icon('times', text: 'Cancel'), path || :back, class: %w[secondary hollow button] + classes
  end

  def back_button(path, model = nil, classes: [])
    link_to fa_icon('angle-left', text: "Back #{model.present? ? "to #{model}" : ''}"), path,
            class: %w[small clear secondary button] + classes
  end

  def edit_button(path, model = nil, classes: [])
    link_to fa_icon('edit', text: "Edit #{model}"), path, class: %w[small clear warning button] + classes
  end

  def view_button(path, classes: [])
    link_to fa_icon('search', text: 'Show'), path, class: %w[small clear info button] + classes
  end

  def destroy_button(path, model = nil, classes: [])
    link_to fa_icon('trash', text: "Delete #{model}"), path,
            method: :delete, remote: true, data: {confirm: 'Are you sure?'},
            class: %w[small clear alert button] + classes
  end

  def submit_button(form, text = nil, classes: [])
    form.submit text, class: %w[button] + classes
  end

  def expanded_submit_button(form, text = nil, classes: [])
    form.submit text, class: %w[expanded button] + classes
  end
end
