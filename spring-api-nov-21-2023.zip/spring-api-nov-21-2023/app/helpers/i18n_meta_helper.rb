module I18nMetaHelper
  def require_meta_tag_presence(list)
    list.each { |item| enforce_property(item) }
  end

  def enforce_property(name)
    raise error_message(name) unless content_for? name
  end

  def error_message(name)
    "Page #{name} missing: you must include 'content_for(:#{name})' in your view."
  end
end
