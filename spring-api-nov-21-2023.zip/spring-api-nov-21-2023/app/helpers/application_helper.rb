module ApplicationHelper
  def active?(path)
    'active' if (path != root_path && request.path == path) || (request.path == path && path == root_path)
  end

  def time_zones(country_code)
    TimeZoneList.for(country_code).map { |e| ["(GMT#{e.formatted_offset}) #{e.tzinfo.name}", e.tzinfo.name] }
  end
end
