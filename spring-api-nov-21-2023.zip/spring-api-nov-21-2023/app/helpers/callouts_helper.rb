module CalloutsHelper
  def primary_callout(text = nil, &)
    tag.div fa_icon('info-circle', text: text || capture(&)), class: 'primary callout'
  end

  def alert_callout(text = nil, &)
    tag.div fa_icon('times-circle', text: text || capture(&)), class: 'alert callout'
  end

  def warning_callout(text = nil, &)
    tag.div fa_icon('warning', text: text || capture(&)), class: 'warning callout'
  end

  def success_callout(text = nil, &)
    tag.div fa_icon('check', text: text || capture(&)), class: 'success callout'
  end

  def secondary_callout(text = nil, &)
    tag.div text || capture(&), class: 'secondary callout'
  end
end
