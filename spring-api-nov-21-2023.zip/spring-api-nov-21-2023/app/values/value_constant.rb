class ValueConstant
  def self.constants
    super.map(&:to_s)
  end

  def self.values
    constants.map { |const| const_get(const) }.sort
  end

  def self.all
    constants.map { |const| {const.to_s => const_get(const)} }.sort_by { |hash| hash.values.first }.reduce(:merge)
  end
end
