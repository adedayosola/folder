class Admin < ApplicationRecord
  include HasFullName
  include DeviseRecord
  include HasStrongPassword

  has_encrypted :first_name, :last_name, :email, :unconfirmed_email
  blind_index :email, :unconfirmed_email

  devise :async, :confirmable, :database_authenticatable, :invitable, :lockable,
         :registerable, :recoverable, :rememberable, :timeoutable, :validatable
end
