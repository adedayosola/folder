class Person < ApplicationRecord
  validates :title, length: {maximum: 255}, presence: true
  validates :urge_type, length: {maximum: 255}, presence: true
end
