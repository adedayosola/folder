class Journal < ApplicationRecord
  belongs_to :user

  validates :journal_type, inclusion: {in: %w[urge gambled]}
  validates :gambling_start_at, :gambling_end_at, presence: true
  validates :intensity,
            numericality: {greater_than_or_equal_to: 0, less_than_or_equal_to: 10, only_integer: true, presence: false},
            allow_nil: true

  validates :substances_used, inclusion: {in: [true, false]}, allow_nil: false
  validates :won_money, :urge_outcome, inclusion: {in: [true, false]}, allow_nil: true

  validates :total_money, numericality: {greater_than_or_equal_to: 0, less_than_or_equal_to: 1_000_000_000},
                          allow_nil: true
end
