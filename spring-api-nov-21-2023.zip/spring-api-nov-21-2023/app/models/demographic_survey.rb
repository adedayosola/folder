class DemographicSurvey < ApplicationRecord
  belongs_to :user

  validates :age, :gender, :living_situation, :annual_net_income, :highest_education,
            :duration_in_canada, :current_gambling_treatment, length: {maximum: 255}, presence: true

  validates :race, :money_sources, length: {maximum: 2000}, presence: true
end
