class Activity < ApplicationRecord
  validates :name, length: {maximum: 255}, presence: true
end
