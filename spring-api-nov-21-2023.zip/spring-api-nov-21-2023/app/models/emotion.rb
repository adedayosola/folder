class Emotion < ApplicationRecord
  validates :name, length: {maximum: 255}, presence: true
  validates :color, length: {maximum: 255}, presence: true
end
