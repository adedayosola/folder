require 'csv'

class Export
  TABLES_TO_EXPORT = %i[journals screeners demographic_surveys users].freeze
  USER_COLUMNS_TO_EXPORT = %i[id first_visit_date active deactivation_date privacy_accept_date enrollment_date
                              created_at].freeze

  attr_accessor :errors, :zip

  def initialize
    @errors = []
    @zip = to_zip
  end

  def to_zip # rubocop:disable Metrics/AbcSize, Metrics/MethodLength
    stringio = Zip::OutputStream.write_buffer do |archive|
      TABLES_TO_EXPORT.each do |table_name|
        query = if table_name == :users
                  "SELECT #{USER_COLUMNS_TO_EXPORT.join(', ')} FROM #{table_name}"
                else
                  "SELECT * FROM #{table_name}"
                end
        current_table = ApplicationRecord.connection.execute(query)

        archive.put_next_entry("#{table_name}.csv")
        archive.write csv_file(current_table)
      end
    end

    stringio.string
  rescue StandardError => e
    Rollbar.error(e)
    Rails.logger.error [e.message, *e.backtrace].join($INPUT_RECORD_SEPARATOR)
    @errors << e.message
  end

  private

  def csv_file(current_table)
    CSV.generate(headers: true) do |csv|
      csv << current_table.fields
      current_table.each do |row|
        csv << row.map do |v|
          v.force_encoding('UTF-8') if v.respond_to?(:encoding)
          v
        end
      end
    end
  end
end
