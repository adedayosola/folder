class User < ApplicationRecord
  has_encrypted :email, :unconfirmed_email, :uid
  blind_index :email, :unconfirmed_email, :uid

  devise :database_authenticatable, :registerable, :recoverable, :confirmable, :validatable, :lockable
  include DeviseTokenAuth::Concerns::User

  has_many :journals, dependent: :destroy
  has_many :screeners, dependent: :destroy
  has_one :demographic_survey, dependent: :destroy

  # validates :password, presence: true, length: {maximum: 255}, if: :new_record?
  validate :password_complexity, if: :new_record?

  def password_complexity
    return if password.blank? || password =~ /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{12,64}$/

    errors.add :password, 'Password should be 12-64 characters and include: 1 uppercase, 1 lowercase, 1 digit and 1 special character' # rubocop:disable Layout/LineLength
  end

  def completed_pgsi?
    screeners.find_by(screener_type: 'PGSI').present?
  end

  def latest_gsas
    screeners.where(screener_type: 'GSAS').maximum(:created_at)
  end

  def completed_demographic_survey?
    demographic_survey.present?
  end

  def active_for_authentication?
    active? && super
  end
end
