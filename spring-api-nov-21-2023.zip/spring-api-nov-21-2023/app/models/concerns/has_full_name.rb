module HasFullName
  extend ActiveSupport::Concern

  included do
    validates :first_name, :last_name, presence: true, length: {maximum: 255}
  end
end
