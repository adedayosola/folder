module DeviseRecord
  extend ActiveSupport::Concern

  included do
    validates :email, 'valid_email_2/email': {disposable: true}
    validates :time_zone, inclusion: {in: TZInfo::DataTimezone.all.map(&:name)}

    def active_for_authentication?
      super && (respond_to?(:enabled) ? enabled? : true)
    end
  end
end
