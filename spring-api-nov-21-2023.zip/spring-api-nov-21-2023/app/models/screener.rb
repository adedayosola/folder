class Screener < ApplicationRecord
  belongs_to :user

  validates :screener_type, length: {maximum: 255}, inclusion: {in: %w[PGSI GSAS]}
  validates :score, numericality: {only_integer: true, greater_than_or_equal_to: 0, less_than_or_equal_to: 48}
end
