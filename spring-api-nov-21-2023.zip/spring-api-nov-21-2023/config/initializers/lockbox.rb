Lockbox.master_key = if Rails.env.development? || Rails.env.test?
                       'c37fc6f43e4125ffd9b89248ff2a59675494659c66de1a4b4c554b13e11b3dbe'
                     else
                       ENV.fetch('LOCKBOX_MASTER_KEY', nil)
                     end
