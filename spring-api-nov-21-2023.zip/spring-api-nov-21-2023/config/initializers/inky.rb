Inky.configure do |config|
  config.template_engine = :haml
end
