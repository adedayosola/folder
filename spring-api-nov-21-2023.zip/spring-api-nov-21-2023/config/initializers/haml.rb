# Compress HAML output
Haml::Template.options[:remove_whitespace] = true
