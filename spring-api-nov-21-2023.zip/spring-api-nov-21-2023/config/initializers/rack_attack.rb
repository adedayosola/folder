# Rate limit by IP for API requests
Rack::Attack.throttle('requests by ip', limit: 30, period: 1.minute) do |req|
  req.ip if req.path.start_with?('/api')
end

# Rate limit auth requests based on email
Rack::Attack.throttle('limit auth attempts per email', limit: 6, period: 1.minute) do |req|
  if req.path.start_with?('/api/users/auth') && req.post?
    req.params['val1'].to_s.downcase.gsub(/\s+/, '') # val1 = email
  end
end

# Always allow requests from localhost - (blocklist & throttles are skipped)
Rack::Attack.safelist('allow from localhost') do |req|
  # Requests are allowed if the return value is truthy
  req.ip == '127.0.0.1' || req.ip == '::1'
end
