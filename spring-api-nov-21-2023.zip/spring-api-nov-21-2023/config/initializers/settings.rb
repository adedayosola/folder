APP = YAML.safe_load(Rails.root.join('config/settings.yml').read, aliases: true).with_indifferent_access
