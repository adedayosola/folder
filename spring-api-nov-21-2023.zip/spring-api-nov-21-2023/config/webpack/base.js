const { webpackConfig } = require('@rails/webpacker')

module.exports = webpackConfig
