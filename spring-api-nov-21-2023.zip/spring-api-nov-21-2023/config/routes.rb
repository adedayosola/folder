Rails.application.routes.draw do
  root 'pages#home'

  devise_for :admins
  get 'profile', to: 'admins#show'

  resources :admins, only: %i[index destroy] do
    post :resend_invitation, on: :member
  end

  get 'export', to: 'exports#all'

  devise_for :users, skip: %i[sessions registrations], controllers: {
    confirmations: 'devise_overrides/confirmations',
    passwords: 'devise_overrides/passwords',
    unlocks: 'devise_overrides/unlocks'
  }

  devise_scope :user do
    scope 'users/password', controller: 'devise_overrides/passwords', as: :user_password do
      get 'success'
    end
    scope 'users/unlock', controller: 'devise_overrides/unlocks', as: :user_unlock do
      get 'success'
    end
  end

  namespace :api, defaults: {format: :json} do
    mount_devise_token_auth_for 'User', at: '/users/auth', skip: [:omniauth_callbacks], controllers: {
      passwords: 'api/devise_token_auth_overrides/passwords',
      sessions: 'api/devise_token_auth_overrides/sessions',
      registrations: 'api/devise_token_auth_overrides/registrations',
      confirmations: 'api/devise_token_auth_overrides/confirmations'
    }

    post 'users/subscribe_enrollment', to: 'users#subscribe_enrollment'
    post 'users/unsubscribe_enrollment', to: 'users#unsubscribe_enrollment'
    post 'users/accept_privacy_policy', to: 'users#accept_privacy_policy'

    resources :journals, except: %i[new edit show]
    resources :screeners, only: %i[index create]
    resources :demographic_surveys, only: %i[create]

    resources :activities, only: %i[index]
    resources :emotions, only: %i[index]
    resources :thoughts, only: %i[index]
    resources :games, only: %i[index]
    resources :locations, only: %i[index]
    resources :people, only: %i[index]

    match '*404', to: 'errors#not_found', via: :all
    match '/500', to: 'errors#internal_server_error', via: :all
  end

  match '/401', to: 'errors#unauthorized', via: :all
  match '/404', to: 'errors#not_found', via: :all
  match '/500', to: 'errors#internal_server_error', via: :all
  match '/', to: 'errors#not_found', via: :all
  match '*404', to: 'errors#not_found', via: :all, constraints: lambda { |req|
    req.path.exclude? 'rails/active_storage'
  }
end
