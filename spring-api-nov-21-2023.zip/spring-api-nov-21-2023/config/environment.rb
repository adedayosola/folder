# Load the Rails application.
require_relative 'application'

CONFIG = YAML.safe_load(Rails.root.join('config/application.yml').read,
                        aliases: true).with_indifferent_access[Rails.env]

# Definite common environment variables
Rails.application.configure do
  # Sets host for the mailer assets, as the mailer instance doesn't have any context about the incoming request.
  config.action_mailer.asset_host = "#{CONFIG[:protocol]}://#{CONFIG[:host]}:#{CONFIG[:port]}"

  # Enables URL helpers so that mailers can hook into routes such as root_url.
  config.action_mailer.default_url_options = {host: CONFIG[:host], port: CONFIG[:port], protocol: CONFIG[:protocol]}

  # Protecting against host header attacks, except in environments specified below
  config.hosts << CONFIG[:host]
  config.hosts.clear if %w[development test].include? Rails.env
end

# Initialize the Rails application.
Rails.application.initialize!
